// For Visual Studios
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "glad/glad.h"  //Include order can matter here
#if defined(__APPLE__) || defined(__linux__)
#include <SDL3/SDL.h>
#include <SDL3/SDL_opengl.h>
#else
#include <SDL.h>
#include <SDL_opengl.h>
#endif
#include <cstdio>

#define GLM_FORCE_RADIANS
#include <cstdio>
#include <fstream>
#include <iostream>
#include <queue>
#include <sstream>
#include <string>
#include <vector>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

bool saveOutput = true;
float dt = 0;

std::string readFile(const std::string& filepath) {
  std::ifstream file(filepath);
  if (!file.is_open()) {
    std::cerr << "Failed to open file: " << filepath << std::endl;
    return "";
  }
  std::stringstream buffer;
  buffer << file.rdbuf();
  return buffer.str();
}

struct TileMap {
  int width, height;
  std::vector<std::vector<char>> tiles;
};
struct key {
  glm::vec3 pos;
  bool held = false;
  bool used = false;
};
struct door {
  glm::vec3 pos;
  bool closed = true;
};

TileMap loadTileMap(const std::string& filename) {
  std::ifstream file(filename);
  TileMap map;

  file >> map.width >> map.height;

  map.tiles.resize(map.height, std::vector<char>(map.width));

  std::string line;

  for (int y = 0; y < map.height; y++) {
    file >> line;

    for (int x = 0; x < map.width; x++) {
      map.tiles[y][x] = line[x];
    }
  }

  return map;
}

std::vector<std::vector<int>> calculateDistances(
    int playerX, int playerY, TileMap* map, const std::vector<door>& doors) {
  std::vector<std::vector<int>> dist(map->height,
                                     std::vector<int>(map->width, -1));
  std::queue<std::pair<int, int>> q;

  dist[playerY][playerX] = 0;
  q.push({playerX, playerY});

  const int dx[4] = {1, -1, 0, 0};
  const int dy[4] = {0, 0, 1, -1};

  while (!q.empty()) {
    auto [cx, cy] = q.front();
    q.pop();

    int currentDist = dist[cy][cx];

    for (int i = 0; i < 4; ++i) {
      int nx = cx + dx[i];
      int ny = cy + dy[i];

      if (nx < 0 || nx >= map->width || ny < 0 || ny >= map->height) continue;

      if (map->tiles[ny][nx] == 'W' ||
          (map->tiles[ny][nx] == 'A' && doors[0].closed) ||
          (map->tiles[ny][nx] == 'B' && doors[1].closed) ||
          (map->tiles[ny][nx] == 'C' && doors[2].closed) ||
          (map->tiles[ny][nx] == 'D' && doors[3].closed) ||
          (map->tiles[ny][nx] == 'E' && doors[4].closed))
        continue;

      if (dist[ny][nx] != -1) continue;

      dist[ny][nx] = currentDist + 1;
      q.push({nx, ny});
    }
  }

  return dist;
}

bool checkCollision(const glm::vec3& newPos,
                    const std::vector<glm::vec3>& cubes,
                    std::vector<door>& doors, std::vector<key>& keys,
                    float playerSize) {
  for (const auto& cube : cubes) {
    if (newPos.x + playerSize > cube.x - 0.5f &&
        newPos.x - playerSize < cube.x + 0.5f &&
        newPos.y + playerSize > cube.y - 0.5f &&
        newPos.y - playerSize < cube.y + 0.5f) {
      return true;
    }
  }
  for (int i = 0; i < doors.size(); i++) {
    if (newPos.x + playerSize > doors[i].pos.x - 0.5f &&
        newPos.x - playerSize < doors[i].pos.x + 0.5f &&
        newPos.y + playerSize > doors[i].pos.y - 0.5f &&
        newPos.y - playerSize < doors[i].pos.y + 0.5f && doors[i].closed) {
      if (keys[i].held) {
        doors[i].closed = false;
        keys[i].used = true;
        keys[i].held = false;
      }
      return true;
    }
  }
  return false;
}
void checkKeyCollision(const glm::vec3& newPos, std::vector<key>& keys,
                       float playerSize) {
  bool anyHeld = false;
  for (const auto& k : keys) {
    if (k.held && !k.used) {
      anyHeld = true;
      break;
    }
  }
  if (anyHeld) return;
  for (auto& key : keys) {
    if (key.used == true) {
      continue;
    }
    if (newPos.x + playerSize > key.pos.x - 0.5f &&
        newPos.x - playerSize < key.pos.x + 0.5f &&
        newPos.y + playerSize > key.pos.y - 0.5f &&
        newPos.y - playerSize < key.pos.y + 0.5f && !key.used) {
      key.held = true;
    }
  }
}

bool checkGameWon(glm::vec3 goalPos, glm::vec3 playerPos, float playerSize) {
  if (playerPos.x + playerSize > goalPos.x - 0.5f &&
      playerPos.x - playerSize < goalPos.x + 0.5f &&
      playerPos.y + playerSize > goalPos.y - 0.5f &&
      playerPos.y - playerSize < goalPos.y + 0.5f) {
    return true;
  }
  return false;
}

void shoot(const glm::vec3& cameraPos, const glm::vec3& cameraTarget,
           const TileMap& map, const std::vector<door>& doors,
           std::vector<glm::vec3>& enemyPositions) {
  if (enemyPositions.empty()) return;

  glm::vec3 dir = glm::normalize(cameraTarget);

  float maxDistance = 20.0f;  // how far the gun can shoot
  float step = 0.05f;         // ray step size
  float t = 0.0f;

  // We’ll track the closest hit enemy
  int hitEnemyIndex = -1;
  float hitEnemyDist = maxDistance;

  while (t < maxDistance) {
    glm::vec3 point = cameraPos + dir * t;

    int tx = (int)std::round(point.x);
    int ty = (int)std::round(point.y);
    ty = map.height - 1 - ty;

    // Check boundaries
    if (tx < 0 || tx >= map.width || ty < 0 || ty >= map.height) break;

    char tile = map.tiles[ty][tx];

    // If we hit a wall or door tile, the ray stops
    if (map.tiles[ty][tx] == 'W' ||
        (map.tiles[ty][tx] == 'A' && doors[0].closed) ||
        (map.tiles[ty][tx] == 'B' && doors[1].closed) ||
        (map.tiles[ty][tx] == 'C' && doors[2].closed) ||
        (map.tiles[ty][tx] == 'D' && doors[3].closed) ||
        (map.tiles[ty][tx] == 'E' && doors[4].closed)) {
      break;
    }

    // Check enemies near this point
    for (int i = 0; i < (int)enemyPositions.size(); ++i) {
      glm::vec3 enemy = enemyPositions[i];

      // Enemy is roughly in the same tile?
      float dx = enemy.x - point.x;
      float dy = enemy.y - point.y;
      float dist2 = dx * dx + dy * dy;

      float hitRadius = 0.7f;  // how close the ray must pass

      if (dist2 < hitRadius * hitRadius) {
        float dist = t;  // along the ray

        if (dist < hitEnemyDist) {
          hitEnemyDist = dist;
          hitEnemyIndex = i;
        }
      }
    }

    t += step;
  }

  if (hitEnemyIndex != -1) {
    std::cout << "Enemy shot! index = " << hitEnemyIndex << std::endl;
    enemyPositions.erase(enemyPositions.begin() + hitEnemyIndex);
  }
}

bool fullscreen = false;
int screen_width = 1200;
int screen_height = 900;

char window_title[] = "Project 4 Game";

float avg_render_time = 0;

bool debug = false;

// void Win2PPM(int width, int height);

// main function updated for SDL3 and with debugging checks

int main(int argc, char* argv[]) {
  if (argc > 1) {
    std::string lastArg = argv[argc - 1];
    if (lastArg == "debug") {
      debug = true;
    }
  }
  SDL_Init(SDL_INIT_VIDEO);  // Initialize Graphics (for OpenGL)

  // Print the version of SDL we are using (should be 3.x or higher)
  const int sdl_linked = SDL_GetVersion();
  printf("\nCompiled against SDL version %d.%d.%d ...\n",
         SDL_VERSIONNUM_MAJOR(SDL_VERSION), SDL_VERSIONNUM_MINOR(SDL_VERSION),
         SDL_VERSIONNUM_MICRO(SDL_VERSION));
  printf("Linking against SDL version %d.%d.%d.\n",
         SDL_VERSIONNUM_MAJOR(sdl_linked), SDL_VERSIONNUM_MINOR(sdl_linked),
         SDL_VERSIONNUM_MICRO(sdl_linked));

  // Ask SDL to get a recent version of OpenGL (3.2 or greater)
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);

  // Create a window (title, width, height, flags)

  SDL_Window* window = SDL_CreateWindow(window_title, screen_width,
                                        screen_height, SDL_WINDOW_OPENGL);
  float aspect =
      screen_width / (float)screen_height;  // aspect ratio (needs to be updated
                                            // if the window is resized)
  // The above window cannot be resized which makes some code slightly easier.
  // Below we show how to make a full screen window or allow resizing
  // SDL_Window* window = SDL_CreateWindow(window_title, screen_width,
  // screen_height, SDL_WINDOW_FULLSCREEN|SDL_WINDOW_OPENGL); SDL_Window* window
  // = SDL_CreateWindow(window_title, screen_width, screen_height,
  // SDL_WINDOW_RESIZABLE|SDL_WINDOW_OPENGL);
  if (!window) {
    printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
    SDL_Quit();
    return 1;
  }
  bool mouseMode = true;
  SDL_SetWindowRelativeMouseMode(window, mouseMode);

  // Create a context to draw in
  SDL_GLContext context = SDL_GL_CreateContext(window);

  if (gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress)) {
    printf("\nOpenGL loaded\n");
    printf("Vendor:   %s\n", glGetString(GL_VENDOR));
    printf("Renderer: %s\n", glGetString(GL_RENDERER));
    printf("Version:  %s\n\n", glGetString(GL_VERSION));
  } else {
    printf("ERROR: Failed to initialize OpenGL context.\n");
    return -1;
  }

  // --- Model Loading with Error Checking ---
  std::string file_name = "models/cube.txt";
  std::ifstream modelFile(file_name);
  if (!modelFile.is_open()) {
    printf("ERROR: Model file '%s' not found or could not be opened.\n",
           file_name.c_str());
    printf("Ensure the 'models' folder is next to your executable.\n");
    SDL_GL_DestroyContext(context);
    SDL_Quit();
    return 1;
  }

  int numModelParams = 0;
  modelFile >> numModelParams;
  if (numModelParams <= 0) {
    printf(
        "ERROR: Model file is empty or does not start with a valid float "
        "count.\n");
    SDL_GL_DestroyContext(context);
    SDL_Quit();
    return 1;
  }

  float* modelData = new float[numModelParams];
  for (int i = 0; i < numModelParams; i++) {
    modelFile >> modelData[i];
  }
  modelFile.close();
  // now that data is read calculate the tangents and bitangents.
  std::vector<glm::vec3> vertices;
  std::vector<glm::vec2> uvs;

  int stride = 8;
  int vertexCount = numModelParams / stride;

  vertices.reserve(vertexCount);
  uvs.reserve(vertexCount);

  for (int i = 0; i < vertexCount; ++i) {
    int base = i * stride;

    glm::vec3 pos(modelData[base + 0], modelData[base + 1],
                  modelData[base + 2]);
    vertices.push_back(pos);

    glm::vec2 uv(modelData[base + 3], modelData[base + 4]);
    uvs.push_back(uv);

    // Normals are at base+5..+7 if needed
  }
  std::vector<glm::vec3> tangents;
  std::vector<glm::vec3> bitangents;
  for (int i = 0; i < vertices.size(); i += 3) {
    glm::vec3& v0 = vertices[i + 0];
    glm::vec3& v1 = vertices[i + 1];
    glm::vec3& v2 = vertices[i + 2];

    glm::vec2& uv0 = uvs[i + 0];
    glm::vec2& uv1 = uvs[i + 1];
    glm::vec2& uv2 = uvs[i + 2];

    glm::vec3 deltaPos1 = v1 - v0;
    glm::vec3 deltaPos2 = v2 - v0;

    glm::vec2 deltaUV1 = uv1 - uv0;
    glm::vec2 deltaUV2 = uv2 - uv0;

    float r = 1.0f / (deltaUV1.x * deltaUV2.y - deltaUV1.y * deltaUV2.x);
    glm::vec3 tangent = (deltaPos1 * deltaUV2.y - deltaPos2 * deltaUV1.y) * r;
    glm::vec3 bitangent = (deltaPos2 * deltaUV1.x - deltaPos1 * deltaUV2.x) * r;

    tangents.push_back(tangent);
    tangents.push_back(tangent);
    tangents.push_back(tangent);

    bitangents.push_back(bitangent);
    bitangents.push_back(bitangent);
    bitangents.push_back(bitangent);
  }

  std::string file_name1 = "models/knot.txt";
  std::ifstream modelFile1(file_name1);
  if (!modelFile1.is_open()) {
    printf("ERROR: Model file '%s' not found or could not be opened.\n",
           file_name.c_str());
    printf("Ensure the 'models' folder is next to your executable.\n");
    SDL_GL_DestroyContext(context);
    SDL_Quit();
    return 1;
  }

  int numModelParams1 = 0;
  modelFile1 >> numModelParams1;
  if (numModelParams1 <= 0) {
    printf(
        "ERROR: Model file is empty or does not start with a valid float "
        "count.\n");
    SDL_GL_DestroyContext(context);
    SDL_Quit();
    return 1;
  }

  float* modelData1 = new float[numModelParams1];
  for (int i = 0; i < numModelParams1; i++) {
    modelFile1 >> modelData1[i];
  }
  modelFile1.close();

  printf("Model total float count: %d\n", numModelParams);
  printf("Model total float count: %d\n", numModelParams1);
  const int paramsPerVertex = 8;  // Assumes X,Y,Z, U,V, Nx,Ny,Nz
  int numVertices = numModelParams / paramsPerVertex;
  int numVertices1 = numModelParams1 / paramsPerVertex;

  std::string vertexSource = readFile("./shaders/vertex.glsl");
  std::string fragmentSource = readFile("./shaders/fragment.glsl");

  // Load the vertex Shader
  const char* vertexSourceCStr = vertexSource.c_str();
  GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
  glShaderSource(vertexShader, 1, &vertexSourceCStr, NULL);
  glCompileShader(vertexShader);

  // Let's double check the shader compiled
  GLint status;
  glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
  if (!status) {
    char buffer[512];
    glGetShaderInfoLog(vertexShader, 512, NULL, buffer);
    printf("Vertex Shader Compile Failed. Info:\n\n%s\n", buffer);
  }

  const char* fragmentSourceCStr = fragmentSource.c_str();
  GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
  glShaderSource(fragmentShader, 1, &fragmentSourceCStr, NULL);
  glCompileShader(fragmentShader);

  // Double check the shader compiled
  glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &status);
  if (!status) {
    char buffer[512];
    glGetShaderInfoLog(fragmentShader, 512, NULL, buffer);
    printf("Fragment Shader Compile Failed. Info:\n\n%s\n", buffer);
  }

  // Join the vertex and fragment shaders together into one program
  GLuint shaderProgram = glCreateProgram();
  glAttachShader(shaderProgram, vertexShader);
  glAttachShader(shaderProgram, fragmentShader);
  glBindFragDataLocation(shaderProgram, 0, "outColor");  // set output
  glLinkProgram(shaderProgram);
  glUseProgram(shaderProgram);

  GLuint textureWall;
  glGenTextures(1, &textureWall);
  glBindTexture(GL_TEXTURE_2D, textureWall);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

  int width, height, nrChannels;
  unsigned char* data =
      stbi_load("./Images/Brick.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  GLuint textureFloor;
  glGenTextures(1, &textureFloor);
  glBindTexture(GL_TEXTURE_2D, textureFloor);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/wood.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);
  GLuint textureGhost;
  glGenTextures(1, &textureGhost);
  glBindTexture(GL_TEXTURE_2D, textureGhost);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/ghost.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  GLuint textureDoor;
  glGenTextures(1, &textureDoor);
  glBindTexture(GL_TEXTURE_2D, textureDoor);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/door.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  GLuint bumpTexture;
  glGenTextures(1, &bumpTexture);
  glBindTexture(GL_TEXTURE_2D, bumpTexture);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/NormalMap.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  GLuint bumpFloorTexture;
  glGenTextures(1, &bumpFloorTexture);
  glBindTexture(GL_TEXTURE_2D, bumpFloorTexture);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/woodNorm.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  GLuint bumpDoorTexture;
  glGenTextures(1, &bumpDoorTexture);
  glBindTexture(GL_TEXTURE_2D, bumpDoorTexture);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  data = stbi_load("./Images/door_normal.png", &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cout << "Failed to load texture" << std::endl;
  }
  stbi_image_free(data);

  // Build a Vertex Array Object. This stores the VBO and attribute mappings in
  // one object
  GLuint vao;
  glGenVertexArrays(1, &vao);  // Create a VAO
  glBindVertexArray(vao);  // Bind the above created VAO to the current context

  // Allocate memory on the graphics card to store geometry (vertex buffer
  // object)

  GLuint tangentVBO, bitangentVBO;
  glGenBuffers(1, &tangentVBO);
  glBindBuffer(GL_ARRAY_BUFFER, tangentVBO);
  glBufferData(GL_ARRAY_BUFFER, tangents.size() * sizeof(glm::vec3),
               tangents.data(), GL_STATIC_DRAW);
  GLint tanAttrib = glGetAttribLocation(shaderProgram, "tangent");
  glVertexAttribPointer(tanAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glEnableVertexAttribArray(tanAttrib);

  // Bitangents
  glGenBuffers(1, &bitangentVBO);
  glBindBuffer(GL_ARRAY_BUFFER, bitangentVBO);
  glBufferData(GL_ARRAY_BUFFER, bitangents.size() * sizeof(glm::vec3),
               bitangents.data(), GL_STATIC_DRAW);
  GLint bitanAttrib = glGetAttribLocation(shaderProgram, "bitangent");
  glVertexAttribPointer(bitanAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glEnableVertexAttribArray(bitanAttrib);

  GLuint vbo[1];
  glGenBuffers(1, vbo);  // Create 1 buffer called vbo
  glBindBuffer(GL_ARRAY_BUFFER,
               vbo[0]);  // Set the vbo as the active array buffer (Only one
                         // buffer can be active at a time)
  glBufferData(GL_ARRAY_BUFFER, numModelParams * sizeof(float), modelData,
               GL_STATIC_DRAW);  // upload vertices to vbo
  // GL_STATIC_DRAW means we won't change the geometry, GL_DYNAMIC_DRAW =
  // geometry changes infrequently GL_STREAM_DRAW = geom. changes frequently.
  // This effects which types of GPU memory is used

  // Tangents

  // --- Vertex Attribute Setup ---
  // This setup assumes the data in our file is formatted as:
  // 8 floats per vertex: [X, Y, Z, U, V, Nx, Ny, Nz]

  GLint posAttrib = glGetAttribLocation(shaderProgram, "position");
  glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE,
                        paramsPerVertex * sizeof(float), 0);
  // Attribute, vals/attrib., type, is_normalized, stride, offset
  // Binds to VBO current GL_ARRAY_BUFFER
  glEnableVertexAttribArray(posAttrib);

  // E.g., if you had color data per vertex, you would do this:
  // GLint colAttrib = glGetAttribLocation(shaderProgram, "inColor");
  // glVertexAttribPointer(colAttrib, 3, GL_FLOAT, GL_FALSE,
  // paramsPerVertex*sizeof(float), (void*)(3*sizeof(float)));
  // glEnableVertexAttribArray(colAttrib);

  GLint normAttrib = glGetAttribLocation(shaderProgram, "inNormal");
  // Normal data starts after 5 floats (X,Y,Z,U,V)
  glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE,
                        paramsPerVertex * sizeof(float),
                        (void*)(5 * sizeof(float)));
  glEnableVertexAttribArray(normAttrib);

  GLint texAttrib = glGetAttribLocation(shaderProgram, "texCoord");
  glVertexAttribPointer(texAttrib,
                        2,  // U, V
                        GL_FLOAT, GL_FALSE, paramsPerVertex * sizeof(float),
                        (void*)(3 * sizeof(float))  // after X,Y,Z
  );
  glEnableVertexAttribArray(texAttrib);

  glBindVertexArray(0);  // Unbind the VAO

  GLuint keyVao;
  glGenVertexArrays(1, &keyVao);  // Create a VAO
  glBindVertexArray(
      keyVao);  // Bind the above created VAO to the current context

  // Allocate memory on the graphics card to store geometry (vertex buffer
  // object)
  GLuint keyVbo[1];
  glGenBuffers(1, keyVbo);  // Create 1 buffer called vbo
  glBindBuffer(GL_ARRAY_BUFFER,
               keyVbo[0]);  // Set the vbo as the active array buffer (Only one
                            // buffer can be active at a time)
  glBufferData(GL_ARRAY_BUFFER, numModelParams1 * sizeof(float), modelData1,
               GL_STATIC_DRAW);  // upload vertices to vbo
  // GL_STATIC_DRAW means we won't change the geometry, GL_DYNAMIC_DRAW =
  // geometry changes infrequently GL_STREAM_DRAW = geom. changes frequently.
  // This effects which types of GPU memory is used

  // --- Vertex Attribute Setup ---
  // This setup assumes the data in our file is formatted as:
  // 8 floats per vertex: [X, Y, Z, U, V, Nx, Ny, Nz]

  GLint keyposAttrib = glGetAttribLocation(shaderProgram, "position");
  glVertexAttribPointer(keyposAttrib, 3, GL_FLOAT, GL_FALSE,
                        paramsPerVertex * sizeof(float), 0);
  // Attribute, vals/attrib., type, is_normalized, stride, offset
  // Binds to VBO current GL_ARRAY_BUFFER
  glEnableVertexAttribArray(keyposAttrib);

  // E.g., if you had color data per vertex, you would do this:
  // GLint colAttrib = glGetAttribLocation(shaderProgram, "inColor");
  // glVertexAttribPointer(colAttrib, 3, GL_FLOAT, GL_FALSE,
  // paramsPerVertex*sizeof(float), (void*)(3*sizeof(float)));
  // glEnableVertexAttribArray(colAttrib);

  GLint keynormAttrib = glGetAttribLocation(shaderProgram, "inNormal");
  // Normal data starts after 5 floats (X,Y,Z,U,V)
  glVertexAttribPointer(keynormAttrib, 3, GL_FLOAT, GL_FALSE,
                        paramsPerVertex * sizeof(float),
                        (void*)(5 * sizeof(float)));
  glEnableVertexAttribArray(keynormAttrib);

  glBindVertexArray(0);  // Unbind the VAO

  // If you need a second VAO (e.g., if some of the models are stored in a
  // second format) Here is what that looks like-- GLuint vao2;
  // glGenVertexArrays(1, &vao2); //Create the VAO
  // glBindVertexArray(vao2); //Bind the above created VAO to the current
  // context
  //   Creat VBOs ...
  //   Set-up attributes ...
  // glBindVertexArray(0); //Unbind the VAO

  glEnable(GL_DEPTH_TEST);

  // Event Loop (Loop forever processing each event as fast as possible)
  SDL_Event windowEvent;
  bool quit = false;

  float playerSize = 0.25f;

  std::vector<glm::vec3> cubePositions;
  std::vector<glm::vec3> floorPositions;
  std::vector<glm::vec3> enemyPositions;
  std::vector<float> enemyMoveTimers;
  std::vector<door> doors(5);
  std::vector<key> keys(5);
  float lastTicks = (float)SDL_GetTicks();

  // cubePositions.emplace_back(0, 0, 0);

  // Plan open each file then loop through the first 2 nums * each other,
  //  If W then cubePositions.emplace_back(i, j,0)
  //  store player pos
  TileMap map = loadTileMap("./maps/map.txt");

  for (int i = 0; i < 5; i++) {
    doors[i].pos = glm::vec3(map.height * 10);
    keys[i].pos = glm::vec3(map.height * 10);
  }
  glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 0.0f);
  glm::vec3 cameraTarget = glm::vec3(0.0f, 1.0f, 0.0f);
  if (debug) {
    cameraPos = glm::vec3(0.0f, 0.0f, 10.0f);
    cameraTarget = glm::vec3(0.0f, 1.0f, -1.0f);
  }

  glm::vec3 goalPos = glm::vec3(0, 0, 0);

  for (int y = 0; y < map.height; y++) {
    for (int x = 0; x < map.width; x++) {
      int worldY = map.height - 1 - y;
      if (x == 0) {
        cubePositions.emplace_back(x - 1, worldY, 0.0f);
        floorPositions.emplace_back(x - 1, worldY, -1.0f);
      }
      if (y == 0) {
        cubePositions.emplace_back(x, worldY + 1, 0.0f);
        floorPositions.emplace_back(x, worldY + 1, -1.0f);
      }
      if (x == map.width - 1) {
        cubePositions.emplace_back(x + 1, worldY, 0.0f);
        floorPositions.emplace_back(x + 1, worldY, -1.0f);
      }
      if (y == map.height - 1) {
        cubePositions.emplace_back(x, worldY - 1, 0.0f);
        floorPositions.emplace_back(x, worldY - 1, -1.0f);
      }
      if (map.tiles[y][x] == 'W') {
        cubePositions.emplace_back(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'S' && !debug) {
        cameraPos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'S' && debug) {
        cameraPos = glm::vec3(x, worldY, 10.0f);
      } else if (map.tiles[y][x] == 'G') {
        goalPos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'Z') {
        enemyPositions.emplace_back(glm::vec3(x, worldY, 0.0f));
      } else if (map.tiles[y][x] == 'A') {
        doors[0].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'B') {
        doors[1].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'C') {
        doors[2].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'D') {
        doors[3].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'E') {
        doors[4].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'a') {
        keys[0].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'b') {
        keys[1].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'c') {
        keys[2].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'd') {
        keys[3].pos = glm::vec3(x, worldY, 0.0f);
      } else if (map.tiles[y][x] == 'e') {
        keys[4].pos = glm::vec3(x, worldY, 0.0f);
      }
      floorPositions.emplace_back(x, worldY, -1.0f);
    }
  }
  for (const auto& pos : enemyPositions) {
    enemyMoveTimers.push_back(0.1f);  // start ready to move
  }

  float elapsedTime = 0.0f;
  bool running = true;
  float bobFreq = 1.1f;  // start at idle amp
  float bobPhase = sin(1.1f) * 0.09;
  int playerHealth = 5;
  float shootCooldown = 0.0f;
  bool gameWon = false;

  float yaw = 90.0f;
  float pitch = 0.0f;
  float mouseSensitivity = 0.05f;

  while (!quit && !gameWon) {
    running = false;
    gameWon = checkGameWon(goalPos, cameraPos, playerSize);
    // std::cout << gameWon << std::endl;
    float currentTicks = (float)SDL_GetTicks();
    float time_per_frame = currentTicks - lastTicks;
    lastTicks = currentTicks;

    dt = time_per_frame / 1000.0f;
    if (dt > 0.05f) dt = 0.05f;
    elapsedTime += dt;
    if (shootCooldown > 0.0f) {
      shootCooldown -= dt;
    }
    for (auto& t : enemyMoveTimers) {
      t -= dt;
    }
    while (SDL_PollEvent(&windowEvent)) {
      // List of keycodes: https://wiki.libsdl.org/SDL_Keycode - You can get
      // events from many special keys Scancode refers to a keyboard position,
      // keycode refers to the letter (e.g., EU keyboards)
      if (windowEvent.type == SDL_EVENT_QUIT) quit = true;
      if (windowEvent.type == SDL_EVENT_KEY_UP &&
          windowEvent.key.key == SDLK_ESCAPE)
        quit = true;
      if (windowEvent.type == SDL_EVENT_KEY_UP &&
          windowEvent.key.key == SDLK_F) {  // Toggle fullscreen with 'F' key
        fullscreen = !fullscreen;
        SDL_SetWindowFullscreen(window, fullscreen ? SDL_WINDOW_FULLSCREEN : 0);
      }
      if (windowEvent.type == SDL_EVENT_MOUSE_BUTTON_DOWN &&
          windowEvent.button.button == SDL_BUTTON_LEFT) {
        if (shootCooldown <= 0.0f) {
          shoot(cameraPos, cameraTarget, map, doors, enemyPositions);
          shootCooldown = 0.4f;
        }
      }
      if (windowEvent.type == SDL_EVENT_MOUSE_MOTION && mouseMode) {
        float dx = (float)windowEvent.motion.xrel;
        float dy = (float)windowEvent.motion.yrel;

        yaw -= dx * mouseSensitivity;
        pitch -= dy * mouseSensitivity;

        if (pitch > 89.0f) pitch = 89.0f;
        if (pitch < -89.0f) pitch = -89.0f;
        // std::cout << "Mouse dx: " << dx << " dy: " << dy << std::endl;
      }
      if (windowEvent.key.key == SDLK_P &&
          windowEvent.type == SDL_EVENT_KEY_UP) {
        mouseMode = !mouseMode;
        SDL_SetWindowRelativeMouseMode(window, mouseMode ? true : false);
        float a;
        std::cin >> a;
      }
    }

    float yawRad = glm::radians(yaw);
    float pitchRad = glm::radians(pitch);

    // X/Y = maze plane, Z = up
    glm::vec3 front;
    front.x = cos(pitchRad) * cos(yawRad);
    front.y = cos(pitchRad) * sin(yawRad);
    front.z = sin(pitchRad);

    cameraTarget = glm::normalize(front);

    glm::vec3 cameraUp = glm::vec3(0.0f, 0.0f, 1.0f);
    glm::vec3 right = glm::normalize(glm::cross(cameraTarget, cameraUp));

    const bool* state = SDL_GetKeyboardState(NULL);
    glm::vec3 newPos = cameraPos;
    if (state[SDL_SCANCODE_W]) {
      newPos += cameraTarget * 5.0f * dt;
      running = true;
    }
    if (state[SDL_SCANCODE_S]) {
      newPos -= cameraTarget * 5.0f * dt;
      running = true;
    }
    if (state[SDL_SCANCODE_A]) {
      newPos -= right * 5.0f * dt;
      running = true;
    }
    if (state[SDL_SCANCODE_D]) {
      newPos += right * 5.0f * dt;
      running = true;
    }

    glm::vec3 tryPos = cameraPos;
    tryPos.x = newPos.x;

    if (!checkCollision(tryPos, cubePositions, doors, keys, playerSize)) {
      cameraPos.x = tryPos.x;
      running = false;
    }

    tryPos = cameraPos;
    tryPos.y = newPos.y;

    if (!checkCollision(tryPos, cubePositions, doors, keys, playerSize)) {
      cameraPos.y = tryPos.y;
      running = false;
    }
    checkKeyCollision(cameraPos, keys, playerSize);
    // std::cout << keys[0].held << std::endl;
    // std::cout << keys[1].held << std::endl;
    // std::cout << keys[2].held << std::endl;
    // std::cout << keys[3].held << std::endl;
    // std::cout << keys[4].held << std::endl;
    if (debug) {
      cameraPos = newPos;
    }

    int playerX = (int)std::round(cameraPos.x);
    int playerY = (int)std::round(cameraPos.y);
    playerY = map.height - 1 - playerY;
    if (playerX >= 0 && playerX < map.width && playerY >= 0 &&
        playerY < map.height) {
      auto dist = calculateDistances(playerX, playerY, &map, doors);

      const float ENEMY_STEP_INTERVAL = 2.0f;

      for (size_t i = 0; i < enemyPositions.size(); ++i) {
        glm::vec3& enemy = enemyPositions[i];

        int exWorld = (int)std::round(enemy.x);
        int eyWorld = (int)std::round(enemy.y);

        int ex = exWorld;
        int ey = map.height - 1 - eyWorld;

        if (ex < 0 || ex >= map.width || ey < 0 || ey >= map.height) continue;

        int d = dist[ey][ex];
        if (d < 0) {
          // -1 unreachable
          continue;
        }
        if (enemyMoveTimers[i] > 0.0f) {
          if (d == 0 && !debug) {
            // want to damage player and disapear
            std::cout << enemy.x << enemy.y << std::endl;
            playerHealth -= 1;
            enemyPositions.erase(enemyPositions.begin() + i);
            std::cout << enemyPositions[i].x << enemyPositions[i].y
                      << std::endl;
            std::cout << playerHealth << std::endl;
          }
          continue;
        }

        int bestX = ex;
        int bestY = ey;
        int bestD = d;

        const int dx[4] = {1, -1, 0, 0};
        const int dy[4] = {0, 0, 1, -1};

        for (int dir = 0; dir < 4; ++dir) {
          int nx = ex + dx[dir];
          int ny = ey + dy[dir];

          if (nx < 0 || nx >= map.width || ny < 0 || ny >= map.height) continue;

          int nd = dist[ny][nx];
          if (nd >= 0 && nd < bestD) {
            bestD = nd;
            bestX = nx;
            bestY = ny;
          }
        }

        if (bestX != ex || bestY != ey) {
          enemy.x = (float)bestX;
          enemy.y = (float)map.height - 1 - bestY;
          enemyMoveTimers[i] = ENEMY_STEP_INTERVAL;  // reset timer after move
        }
      }
    }

    // Clear the screen to target color and clear depth buffer
    glClearColor(.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 view = glm::lookAt(cameraPos,                 // Cam Position
                                 cameraPos + cameraTarget,  // Look At Point
                                 cameraUp);                 // Up Vector
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE,
                       glm::value_ptr(view));

    glm::mat4 proj = glm::perspective(glm::radians(45.0f), aspect, 0.1f,
                                      100.0f);  // FOV, aspect, near, far
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "proj"), 1, GL_FALSE,
                       glm::value_ptr(proj));

    glm::mat4 uiProj = glm::ortho(0.0f, 1.0f,  // left, right
                                  0.0f, 1.0f,  // bottom, top
                                  -1.0f, 1.0f);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "uiProj"), 1,
                       GL_FALSE, glm::value_ptr(uiProj));

    glUniform3fv(glGetUniformLocation(shaderProgram, "viewPos"), 1,
                 glm::value_ptr(cameraPos));
    glUniform3fv(glGetUniformLocation(shaderProgram, "cameraDir"), 1,
                 glm::value_ptr(glm::normalize(cameraTarget -
                                               glm::vec3(0.0f, 0.0f, 0.05f))));

    float targetFreq = running ? 1.1f : 0.3f;

    float bobSmooth = 10.0f;
    bobFreq += (targetFreq - bobFreq) * bobSmooth * dt;

    bobPhase += 2.0f * 3.14f * bobFreq * dt;

    if (bobPhase > 1000.0f) {
      bobPhase = fmod(bobPhase, 2.0f * 3.14f);
    }

    float amplitude = 0.03f;
    float offset = sin(bobPhase) * amplitude;

    glUniform1f(glGetUniformLocation(shaderProgram, "offset"), offset);
    glUniform1f(glGetUniformLocation(shaderProgram, "debug"), debug);

    glUniform1f(glGetUniformLocation(shaderProgram, "time"), elapsedTime);
    glUniform1f(glGetUniformLocation(shaderProgram, "cutoff"),
                cos(glm::radians(5.0f)));
    glUniform1f(glGetUniformLocation(shaderProgram, "outerCutoff"),
                cos(glm::radians(15.0f)));
    if (debug) {
      glUniform1f(glGetUniformLocation(shaderProgram, "cutoff"),
                  cos(glm::radians(30.0f)));
      glUniform1f(glGetUniformLocation(shaderProgram, "outerCutoff"),
                  cos(glm::radians(35.0f)));
    }

    glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), GL_FALSE);
    glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_FALSE);
    glUniform1f(glGetUniformLocation(shaderProgram, "ambientStrength"), 0.025f);
    if (debug) {
      glUniform1f(glGetUniformLocation(shaderProgram, "ambientStrength"), 0.1f);
    }

    glUniform1f(glGetUniformLocation(shaderProgram, "specularStrength"), 0.5f);
    glUniform1f(glGetUniformLocation(shaderProgram, "shininess"), 24.0f);
    glUseProgram(shaderProgram);

    float startX = 0.1f;  // left margin
    float stepX = 0.06f;  // spacing between health units
    float baseY = 0.1f;   // vertical position (near bottom)
    float size = 0.04f;

    glUniform1i(glGetUniformLocation(shaderProgram, "isUI"), 1);

    glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0));
    model = glm::scale(model, glm::vec3(0.01f));
    if (!debug) {
      glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 1.0f, 1.0f,
                  1.0f);
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                         GL_FALSE, glm::value_ptr(model));

      glDrawArrays(GL_TRIANGLES, 0, numVertices);

      for (int i = 0; i < playerHealth; i++) {
        float x = startX + i * stepX;
        float y = baseY;

        glm::vec3 uiPos(x, y, 0.0f);

        glm::mat4 model = glm::translate(glm::mat4(1.0f), uiPos);
        model = glm::scale(model, glm::vec3(size));

        glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.8f, 0.0f,
                    0.0f);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                           GL_FALSE, glm::value_ptr(model));

        glDrawArrays(GL_TRIANGLES, 0, numVertices);
      }
    }
    // tell the shader that "diffuseTex" is using texture unit 0
    glUniform1i(glGetUniformLocation(shaderProgram, "isUI"), 0);
    GLint diffuseLoc = glGetUniformLocation(shaderProgram, "diffuseTex");

    GLint bumpLoc = glGetUniformLocation(shaderProgram, "bumpMap");

    glBindVertexArray(keyVao);
    for (int i = 0; i < keys.size(); i++) {
      if (!keys[i].used) {
        glm::mat4 model;
        if (!keys[i].held) {
          model = glm::translate(glm::mat4(1.0f),
                                 keys[i].pos - glm::vec3(0, 0, 0.1));
          model = glm::scale(model, glm::vec3(0.3f));
        } else {
          model =
              glm::translate(glm::mat4(1.0f), cameraPos + cameraTarget -
                                                  glm::vec3(0.0f, 0.0f, 0.15f));
          model = glm::scale(model, glm::vec3(0.1f));
        }

        if (i == 0) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.0f, 0.0f);
        }
        if (i == 1) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.5f, 0.0f);
        }
        if (i == 2) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.0f, 0.5f);
        }
        if (i == 3) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f,
                      0.5f, 0.5f);
        }
        if (i == 4) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f,
                      0.0f, 0.5f);
        }
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                           GL_FALSE, glm::value_ptr(model));
        glDrawArrays(GL_TRIANGLES, 0, numVertices1);
      }
    }

    glBindVertexArray(vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureDoor);

    glUniform1i(diffuseLoc, 0);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, bumpDoorTexture);

    glUniform1i(bumpLoc, 1);

    for (int i = 0; i < doors.size(); i++) {
      if (doors[i].closed) {
        glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), GL_TRUE);
        glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_TRUE);
        glm::mat4 model = glm::translate(glm::mat4(1.0f), doors[i].pos);
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
        if (i == 0) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.0f, 0.0f);
        }
        if (i == 1) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.5f, 0.0f);
        }
        if (i == 2) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.5f,
                      0.0f, 0.5f);
        }
        if (i == 3) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f,
                      0.5f, 0.5f);
        }
        if (i == 4) {
          glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f,
                      0.0f, 0.5f);
        }
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                           GL_FALSE, glm::value_ptr(model));
        glDrawArrays(GL_TRIANGLES, 0, numVertices1);
      }
    }
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureWall);
    glUniform1i(diffuseLoc, 0);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, bumpTexture);
    glUniform1i(bumpLoc, 1);
    for (const auto& pos : cubePositions) {
      glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), GL_TRUE);
      glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_TRUE);
      glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f, 0.0f,
                  0.0f);
      glm::mat4 model = glm::translate(glm::mat4(1.0f), pos);
      model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                         GL_FALSE, glm::value_ptr(model));
      glDrawArrays(GL_TRIANGLES, 0, numVertices);
    }
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureGhost);
    glUniform1i(diffuseLoc, 0);
    for (const auto& pos : enemyPositions) {
      glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_FALSE);
      glm::mat4 model = glm::translate(glm::mat4(1.0f), pos);
      model = glm::scale(model, glm::vec3(0.5f));
      glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f, 0.0f,
                  0.0f);
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                         GL_FALSE, glm::value_ptr(model));
      glDrawArrays(GL_TRIANGLES, 0, numVertices);
    }

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureFloor);
    glUniform1i(diffuseLoc, 0);
    for (const auto& pos : floorPositions) {
      glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f, 0.0f,
                  0.0f);
      glActiveTexture(GL_TEXTURE1);
      glBindTexture(GL_TEXTURE_2D, bumpFloorTexture);

      glUniform1i(bumpLoc, 1);
      glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_TRUE);
      glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), GL_TRUE);
      glUniform1i(glGetUniformLocation(shaderProgram, "diffuseTex"), 0);
      glm::mat4 model = glm::translate(glm::mat4(1.0f), pos);
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                         GL_FALSE, glm::value_ptr(model));
      glDrawArrays(GL_TRIANGLES, 0, numVertices);
    }
    glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), GL_FALSE);

    glUniform1i(glGetUniformLocation(shaderProgram, "useBumpMap"), GL_FALSE);

    glUniform3f(glGetUniformLocation(shaderProgram, "inColor"), 0.0f, 0.5f,
                0.0f);
    model = glm::translate(glm::mat4(1.0f), goalPos);
    model = glm::scale(model, glm::vec3(0.5f));
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1,
                       GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, numVertices);

    SDL_GL_SwapWindow(window);  // Double buffering

    // SDL_SetWindowTitle(window, update_title);
  }

  delete[] modelData;

  // Clean Up
  glDeleteProgram(shaderProgram);
  glDeleteShader(fragmentShader);
  glDeleteShader(vertexShader);
  glDeleteBuffers(1, vbo);
  glDeleteVertexArrays(1, &vao);
  SDL_GL_DestroyContext(context);
  SDL_Quit();
  return 0;
}
